package com.ucccwr.urldownload;

import static java.lang.Long.parseLong;
import static java.lang.Math.round;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Pair;
import android.widget.TextView;

import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class AsynchronicExec extends AsyncTask<String, Integer,String[]> {
    TextView fileSize,fileType;
    @Override
    protected String[] doInBackground(String... params) {
        String adres = params[0];
        HttpsURLConnection connection = null;
        long mSize = 0;
        String mTyp= "";
        try {
            URL url = new URL(adres);
            connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept-Encoding", "identity");
            mSize = connection.getContentLength();
            mTyp = connection.getContentType();
        } catch (Exception e) {
            e.printStackTrace();
        }
        String tab[]= {String.valueOf(mSize),mTyp};
        return tab;
    }

    @Override
    protected void onPostExecute(String[] strings){
       long l =  parseLong(strings[0]);
        int mb = round(l/1024/1024);
        fileSize.setText(String.valueOf(mb) + "Mb");
        fileType.setText(strings[1]);
    }

    public AsynchronicExec (Context parsedContext, TextView fileSize, TextView fileType){
        Context context = parsedContext;
        this.fileType = fileType;
        this.fileSize = fileSize;
    }
}